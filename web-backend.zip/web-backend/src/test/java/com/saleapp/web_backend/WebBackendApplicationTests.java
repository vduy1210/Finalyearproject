package com.saleapp.web_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
